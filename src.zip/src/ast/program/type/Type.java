package ast.program.type;

public interface Type {
}
